#include<iostream>
#include<math.h>
using namespace std;
int main(){
	double x;
	cin >> x;
	int res1 = (int)ceil(x);
	int res2 = (int)floor(x);
	int res3 = (int)round(x);
	cout << res2 << endl;
	cout << res1 << endl;
	cout << res3 << endl;
}