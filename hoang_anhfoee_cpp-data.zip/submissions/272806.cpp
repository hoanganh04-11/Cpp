#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int dem_C = 0;
    int dem = 0;
    for(int i=0; i<n; i++){
        char kitu;
        cin >> kitu;
        if(kitu == 'C' ){
            ++dem_C;
        }
        if(kitu == '+'){
        	++dem;
		}
    }
    if(dem_C >=1 && dem>=2) cout << "YES";
    else cout << "NO";
}