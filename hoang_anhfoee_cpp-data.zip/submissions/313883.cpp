#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int min_val= 1e9;
	for(int i=0; i<n; i++){
		for(int j=i+1; j<n; j++){
			min_val = min(min_val, abs(a[i] - a[j]));
		}
	}
	cout << min_val << endl;
}