#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int kq = n/100;
	n = n % 100;
	kq = kq + n/20;
	n = n % 20;
	kq = kq + n/10;
	n = n % 10;
	kq = kq + n/5;
	n = n % 5;
	kq = kq + n/1;
	cout << kq << endl;
}