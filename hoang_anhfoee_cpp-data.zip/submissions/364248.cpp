#include<iostream>
#include<vector>
using namespace std;
int main(){
    int n; cin >> n;
    vector<int> v(n);
    for(int i=0; i<n; i++){
        cin >> v[i];
    }
    for(int i=0; i<(int)v.size()-1; i++){
        for(int j=0; j<(int)v.size()-i-1; j++){
            if(v[j] > v[j+1]){
                int tmp = v[j];
                v[j] = v[j+1];
                v[j+1] = tmp;
            }
        }
    }
    for(int x : v) cout << x << " ";
    cout << endl;
    for(int i=0; i<(int)v.size()-1; i++){
        for(int j=0; j<(int)v.size()-i-1; j++){
            if(v[j] < v[j+1]){
                int tmp = v[j];
                v[j] = v[j+1];
                v[j+1] = tmp;
            }
        }
    }
    for(int x : v) cout << x << " ";
}