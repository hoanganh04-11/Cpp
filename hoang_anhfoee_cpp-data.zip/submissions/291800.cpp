#include<iostream>
using namespace std;
int main(){
	int t;
	cin >> t;
	while(t--){
		int n;
		cin >> n;
		if(n%2==0){
			cout << "EVEN"<< endl;
		}
		else cout << "ODD"<< endl;
	}
}