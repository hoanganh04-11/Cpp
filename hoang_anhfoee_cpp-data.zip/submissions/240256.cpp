#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	long long a,b;
	cin >> a >> b;
	long long x = a + b;
	long long y = a-b;
	long long z = a * b;
	double t = 1.0 * a/b;
	cout << x << endl;
	cout << y << endl;
	cout << z << endl;
	if(b==0){
		cout << "INVALID" << endl;
	}
	else{
		cout << fixed << setprecision(4) << t << endl;
	}
}