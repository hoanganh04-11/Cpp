#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long hour = n/3600;
	long long du= n%3600;
	long long minutes = du/60;
	long long second = du%60;
	cout << hour << "h" << " " << ":" << " " << minutes << "m" << " " << ":" << " " << second << "s" << endl;
}