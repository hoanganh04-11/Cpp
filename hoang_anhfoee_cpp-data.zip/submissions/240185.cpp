#include<iostream>
using namespace std;
int main(){
	int a,b;
	cin >> a >> b;
	int x = (a/b)*b;
	cout << x << endl;
	if(a%b==0){
		cout << a << endl;
	}
	else{
		int y= (a/b+1)*b;
		cout << y <<endl;
	}
}