#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	int c=0;
	int l=0;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		if(a[i]%2==0){
			c += 1;
		}
		else{
			l += 1;
		}
	}
	cout << c << " " << l;
}