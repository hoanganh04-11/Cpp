#include<iostream>
using namespace std;
int main(){
	char c;
	cin >> c;
	if((c>='a') && (c<='z')){
		c -=32;
		cout << c << endl;
	}
	else if((c>='A') && (c<='Z')){
		c +=32;
		cout << c << endl;
	}
	else{
		cout << c << endl;
	}
}