#include<iostream>
using namespace std;
int main(){
	long long x,y,z,t;
	cin >> x >> y >> z >>t;
	long long res1=1ll*2*x;
	long long res2=1ll*3*y;
	long long res3=1ll*4*z;
	long long res4=1ll*5*t;
	cout << x << "  " << y << "  " << z << "  "<< t << endl;
	cout << y << "--" << z << "--" << x << "--" << t << endl;
	cout << res1 << "," << res2 << "," << res3 << "," << res4 << endl;
	cout << "KET THUC !!" << endl;
}