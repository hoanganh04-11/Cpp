#include<iostream>
using namespace std;
int main(){
	int n,m;
	cin >> n >> m;
	int min, max = n;
	if(n % 2 ==0){
		min = n/2;
	}
	else{
		min = n/2+1;
	}
	int kq;
	if(min % m == 0){
		kq = min;
	}
	else{
		kq = (min/m+1)*m;
	}
	if(kq <= max){
		cout << kq << endl;
	}
	else{
		cout << "-1" << endl;
	}
}