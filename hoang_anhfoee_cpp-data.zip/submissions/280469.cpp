#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long sum = (n*(n+1))/2;
	int lastDigit = sum%10;
	if(lastDigit==2||lastDigit==3||lastDigit==5||lastDigit==7){
		cout << "28tech";
	}
	else{
		cout << "29tech";
	}
}