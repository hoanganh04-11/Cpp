#include<bits/stdc++.h>
using namespace std;

bool lt7(long long n){
	while(n % 7 == 0){
		n /= 7;
	}
	if(n==1) return true;
	else return false;
}


int main(){
	long long n;
	cin >> n;
	if(lt7(n)){
		cout << "28tech";
	}
	else cout << "29tech";
}