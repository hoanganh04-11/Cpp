#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long gt=1;
	long long tong=0;
	for(int i=1; i<=n; i++){
		gt*=i;
		tong +=gt;
	}
	cout << tong;
}