#include<iostream>
using namespace std;
#define ll long long

ll rev(ll n){
	ll sum=0;
	while(n>0){
		int r=n%10;
		sum = sum*10 +r;
		n /=10;
	}
	return sum;
}

int main(){
	ll n;
	cin >> n;
	cout << rev(n);
}