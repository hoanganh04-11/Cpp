#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int sum=0;
	while(n>0){
		int r = n % 10;
		sum += r;
		n/=10;
	}
	cout << sum;
}