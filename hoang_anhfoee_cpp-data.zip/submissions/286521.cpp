#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int demEven = 0;
	int demOdd = 0;
	if(n==0){
		++demEven;
	}
	while(n){
		int r = n % 10;
		if(n%2==0){
			++demEven;
		}
		else{
			++demOdd;
		}
		n /= 10;
	}
	if(demEven>demOdd) cout << "28tech" << endl;
	else cout <<"29tech"<< endl;
}