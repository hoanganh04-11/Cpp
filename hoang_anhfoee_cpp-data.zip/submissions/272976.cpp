#include<iostream>
using namespace std;
int main(){
	int gio, phut;
	cin >> gio >> phut;
	int p = 60 * gio + phut;
	cout << 1440 - p;
}