#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	int dem=0;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int min_val = 2e9;
	for(int i=0; i<n; i++){
		if(a[i]<min_val){
			min_val = a[i];
		}
	}
	for(int i=0; i<n; i++){
		if(min_val == a[i]){
			++dem;
		}
	}
	cout << dem;
}