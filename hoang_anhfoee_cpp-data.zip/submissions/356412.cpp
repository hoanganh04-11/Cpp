#include<iostream>
using namespace std;
int main(){
	int n; cin >> n;
	int a[n];
	int x, k; cin >> x >> k;
	for(int i=0; i<n; i++) cin >> a[i];
	for(int i=0; i<n; i++){
		if(i==k-1){ cout << x << " ";
		}
		cout << a[i] << " ";
	}
}