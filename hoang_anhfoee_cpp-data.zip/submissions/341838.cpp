#include<bits/stdc++.h>
using namespace std;

bool amr(int n){
	int dem=0;
	int m = n;
	while(m!=0){
		++dem;
		m /=10;
	}
	m = n;
	long long sum=0;
	while(m!=0){
		int r = m%10;
		sum += pow(r, dem);
		m /= 10;
	}
	if(sum==n){
		return true;
	}
	else return false;
	// reutrn sum==n;
}

int main(){
	int a, b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(amr(i)){
			cout << i << " ";
		}
	}
}