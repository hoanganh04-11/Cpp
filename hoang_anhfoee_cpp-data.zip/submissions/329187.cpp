#include<bits/stdc++.h>
using namespace std;
int main(){
	int n; cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		bool found = false;
		for(int j=0; j<i; j++){
			if(a[j]==a[i]){
				found = true;
				break;
			}
		}
		if(!found){
			int ts=1;
			for(int j=i+1; j<n; j++){
				if(a[j]==a[i]){
					++ts;
				}
			}
		cout << a[i] << " " << ts << endl;
		}	
	}
}