#include<iostream>
#include<math.h>
using namespace std;

bool fi(long long n){
	if(n==0 || n==1){
		return true;
	}
	long long f0=0, f1=1;
	for(int i=2; i<=92; i++){
		long long fn = f0+f1;
		if(n==fn){
			return true;
		}
		f0=f1;
		f1=fn;
	}
	return false;
}

int main(){
	int n; cin >> n;
	long long a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	bool check = false;
	for(int i=0; i<n; i++){
		if(fi(a[i])){
			cout << a[i] << " ";
			check = true;
		}
	}
	if(!check) cout << "NONE";
}