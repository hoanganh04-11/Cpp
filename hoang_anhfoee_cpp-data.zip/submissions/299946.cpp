#include<iostream>
using namespace std;
#define ll long long

ll rev(ll n){
	ll sum=0;
	while(n>0){
		int r=n%10;
		sum = sum*10 +r;
		n /=10;
	}
	return sum;
}

bool palindrome(int n){
	if(n==rev(n)) return 1;
	else return 0;
}

int main(){
	int a,b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(palindrome(i)){
			cout << i << " ";
		}
	}
}