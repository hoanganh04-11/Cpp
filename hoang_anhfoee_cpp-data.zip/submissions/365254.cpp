#include<bits/stdc++.h>
#define ll long long
#define FI first
#define SE second
using namespace std;
int main(){
	int n; cin >> n;
	vector<pair<pair<int, int>, int>> v(n);
	for(int i=0; i<n; i++){
		cin >> v[i].first.first >> v[i].first.second >> v[i].second;
	}
	for(int i=0; i<n; i++){
		long long sum = v[i].first.first + v[i].first.second + v[i].second;
		cout << sum << " ";
	}
}