#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int x=n/500000;
	int y=n - (x*500000);
	cout << x << endl;
	cout << y << endl;
}