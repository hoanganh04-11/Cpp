#include<iostream>
using namespace std;
int main(){
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	int s;
	if(a==0){
		cout << "NO" << endl;
	}
	if(b%a==0){
		s= b/a;
		long long s1 = 1ll * b * s;
		if(c==s1){
			long long s2 = 1ll* s1 * s;
			if(d==s2){
				cout << "YES" << endl;
			}
			else{
			cout << "NO" << endl;
		}
		} 
		else{
		  cout << "NO" << endl;
	}
	}
	else{
		cout << "NO" << endl;
	}
}