#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int kq = n%10;
	while(n!=0){
		int r=n%10;
		if(r>kq){
			kq = r;
		}
		n /=10;
	}
	cout << kq; 
}