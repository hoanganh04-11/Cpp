#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	int x,y,z,t;
	cin >> x;
	cin >> y;
	cin >> z;
	cin >> t; 
	int res1 = max(x,y);
	int res2 = min(z,t);
	int res3 = max({x, y, z});
	int res4 = min({x, y, z, t});
	cout << res1 << endl;
	cout << res2 << endl;
	cout << res3 << endl;
	cout << res4 << endl;
}