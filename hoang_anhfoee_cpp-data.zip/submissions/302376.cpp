#include<iostream>
#include<cmath>
using namespace std;

int main(){
	long long a, b;
	cin >> a >> b;
	int can = ceil(sqrt(a));
	for(int i=can; i<=sqrt(b); i++){
			cout <<1ll * i*i << " ";
	}
}