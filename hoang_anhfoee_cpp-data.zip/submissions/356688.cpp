#include<iostream>
#include<cmath>
using namespace std;
bool csnt(int n){
	while(n != 0){
		int r= n%10;
		if(r != 2 && r != 3 && r != 5 && r != 7){
			return false;
		}
		n /= 10;
	}
	return true;
}

bool nt(int n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0) return false;
	}
	return n>1;
}

int main(){
	int a, b;
	cin >> a >> b;
	long long dem = 0;
	for(int i=a; i<=b; i++){
		if(csnt(i) && nt(i)){
			++dem;
		}
	}
	cout << dem;
}