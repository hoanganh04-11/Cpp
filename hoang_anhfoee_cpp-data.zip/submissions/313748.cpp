#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	bool found= false;
	for(int i=0; i<n; i++){
		if(i%2==0 && a[i]%2==0){
			cout << a[i] << " ";
			found = true;
		}
	}
	if(!found) cout <<"NONE";
}