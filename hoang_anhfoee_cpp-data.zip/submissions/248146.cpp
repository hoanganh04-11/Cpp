#include<iostream>
using namespace std;
int main(){
	int n, u1, d;
	cin >> n >> u1 >> d;
	long long un = u1 + 1ll*(n-1)*d;
	long long s = (u1+un)*n/2;
	cout << s << endl;
}