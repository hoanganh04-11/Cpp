#include<iostream>
#include<math.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long sum=0;
	for(int i=1; i<=n; ++i){
		sum += i;
	}
	cout << sum << endl;
	
	long long sum2=0;
	for (int i=1; i<=n; ++i){
		sum2 += 1ll * i * i ;
	}
	cout << sum2 << endl;
	
	int count = 0;
	for(int i=1; i<=n; ++i){
		if(i%3==0){
			count++;
		}
	}
	cout << count << endl;
	
	long long sum3=0;
	for (int i=1; i<=n; ++i){
		if(i%3==0){
			sum3 += i;
		}
	}
	cout << sum3 << endl;
}