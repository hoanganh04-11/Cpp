#include<bits/stdc++.h>
using namespace std;

bool nt(int n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0) return false;
	}
	return n>1;
}

bool tn(int n){
	int rev=0;
	int m = n;
	while(m!=0){
		rev = rev * 10 + m%10;
		m /=10;
	}
	if(rev == n) return true;
	return false;
}

bool cp(long long n){
	int  can = sqrt(n);
	if(1ll * can * can == n){
		return true;
	}
	return false;
}

int tong(int n){
	int sum=0;
	while(n != 0){
		sum += n%10;
		n /=10;
	}
	if(nt(sum)) return true;
	return false;
}


int main(){
	int n; cin >> n;
	int a[n];
	for(int i=0; i<n; i++) cin >> a[i];
	int demNT=0, demTN=0, demCP=0, demSUM=0;
	for(int i=0; i<n; i++){
		if(nt(a[i])) ++demNT;
		if(tn(a[i])) ++demTN;
		if(cp(a[i])) ++demCP;
		if(tong(a[i])) ++demSUM;
	}	
	cout << demNT << endl << demTN << endl << demCP << endl << demSUM;	
}