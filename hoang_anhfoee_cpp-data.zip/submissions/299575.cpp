#include<iostream>
using namespace std;

void my_swap(int &a, int&b){
	int tmp;
	tmp = a;
	a = b;
	b = tmp;
}

int main(){
	int x, y;
	cin >> x >> y;
	my_swap(x, y);
	cout << x << " " << y << endl;
}