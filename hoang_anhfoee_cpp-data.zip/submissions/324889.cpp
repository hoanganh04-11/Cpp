#include<iostream>
using namespace std;

int demS(int n){
	int dem=0;
	while(n!=0){
		++dem;
		n/=10;
	}
	return dem;
} 

bool soDep(int n){
	int len=demS(n);
	if(len%2==0) return false;
	
	int soGiua=len/2;
	int tmp=n;
	int max_val=0;
	for(int i=0; i<=soGiua; i++){
		int r= tmp%10;
		if(i==soGiua) max_val=r;
		tmp /=10;
	}
	tmp = n;
	for(int i=0; i<len; i++){
		int r=tmp%10;
		if(r>max_val) return false;
		tmp /= 10;
	}
	return true;
}

int main(){
	int a, b;
	cin >> a >> b;
	bool check = false;
	for(int i=a; i<=b; i++){
		if(soDep(i)){
			cout << i << " ";
			check = true;
		}
	}
	if(!check) cout << "28tech" << endl;	
}