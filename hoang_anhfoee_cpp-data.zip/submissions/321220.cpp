#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    int a[n];
    int c=0, l=0;
    long long tongC=0;
    long long tongL=0;
    for(int i=0; i<n; i++){
        cin >> a[i];
    }
    for(int i=0; i<n; i++){
        if(a[i]%2==0){
            ++c;
            tongC += a[i];
        }
        else{
            ++l;
            tongL += a[i];
        }
    }
    cout << c << endl << l << endl << tongC << endl << tongL;
}