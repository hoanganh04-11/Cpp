#include<iostream>
using namespace std;
int main(){
	long long a, b, k;
	cin >> a >> b >> k;
	long long t, p, distance;
	if(k % 2 == 0){
		t = k/2 * a;
		p = k/2 * b;
		distance = t-p;
	}
	else{
		t = (k/2+1)*a;
		p = k/2 * b;
		distance = t-p;
	}
	cout << distance << endl;
}