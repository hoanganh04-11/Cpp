#include<bits/stdc++.h>
using namespace std;
int main(){
	int n; cin >> n;
	vector<int> v;
	for(int i=0; i<n; i++){
		int x; cin >> x;
		v.push_back(x);
	}
	vector<int> :: iterator it;
	cout << *min_element(v.begin(), v.end()) << endl;
	cout << *max_element(v.begin(), v.end()) << endl;
	cout << accumulate(v.begin(), v.end(), 0); 
}