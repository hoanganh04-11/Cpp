#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int year = n/365;
	int week = (n%365)/7;
	int day = (n%365)%7;
	cout << year << " "<< week << " " << day << endl;
}