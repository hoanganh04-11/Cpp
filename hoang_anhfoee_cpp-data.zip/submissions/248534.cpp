#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long kq =1ll* n*(n-1)/2;
	cout << kq << endl;
}