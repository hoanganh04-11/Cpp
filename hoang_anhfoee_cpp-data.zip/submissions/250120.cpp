#include<iostream>
using namespace std;

int sum_digit(long long n){
	long long sum = 0;
	while(n){
		long long r = n%10;
		sum += r;
		n /= 10;
	}
	return sum;
}

int main(){
	long long n;
	cin >> n;
	sum_digit(n);
	long long kq= sum_digit(n);
	cout << kq << endl;
}