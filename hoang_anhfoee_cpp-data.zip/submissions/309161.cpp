#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long sum=0;
	int m;
	for(int i=1; i<=n; i++){
		cin >> m;
		if(m%2==0){
			sum += m;
		}
	}
	cout << sum << endl;
}