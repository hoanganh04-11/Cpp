#include<iostream>
using namespace std;
int main(){
	int n, x; cin >> n >> x;
	int a[n];
	for(int i=0; i<n; i++) cin >> a[i];
	bool found = false;
	for(int i=0; i<n; i++){
		if(a[i] == x){
			found = true;
			for(int j=i; j<n-1; j++){
				a[j] = a[j+1];
			}
			--n;
			break;
		}
		}
	if(!found) cout <<  "NOT FOUND";
	else{
		for(int i=0; i<n; i++){
			cout << a[i] << " ";
		}
	}
}