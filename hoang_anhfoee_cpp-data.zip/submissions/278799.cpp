#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long last = n % 10;
	while(n >= 10){
		n /= 10;	
	}
	long long first = n;
	cout << first << " ";
	cout << last << endl;
}