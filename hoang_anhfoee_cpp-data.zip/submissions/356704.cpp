#include<iostream>
#include<cmath>
using namespace std;

long long gcd(long long a, long long b){
	while(b!=0){
		int du = a%b;
		a = b;
		b = du;
	}
	return a;
}

int main(){
	long long a, b;
	cin >> a >> b;
	long long lcd = a / gcd(a,b) * b;
	cout << gcd(a, b) << " " << lcd;
}