#include<iostream>
using namespace std;
int main(){
	long long n, x;
	cin >> n >> x;
	long long vo= n/x;
	cout << "SO VO MUA DUOC LA : " << vo << " !!!!!" << endl;
}