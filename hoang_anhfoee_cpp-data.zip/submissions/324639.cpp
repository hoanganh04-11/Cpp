#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int tongC=0;
	if(n<0){
		cout << "NEGATIVE";
	}
	else{
		while(n!=0){
			int r=n%10;
			if(r%2==0){
				tongC += r;
			}
			n /= 10;
		}
		cout << tongC; 
	}
}