#include<iostream>
#include<cmath>
using namespace std;

void solve(int &x){
	x *=28;
}

int main(){
	int n;
	cin>>n;
	solve(n);
	cout << n << endl;
}