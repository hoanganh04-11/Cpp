#include<iostream>
using namespace std;
int main(){
	int a1, a2, a3, b1, b2, b3, n;
	int kq, kq1;
	cin >> a1 >> a2 >> a3 >> b1 >> b2 >> b3 >> n;
	int cup = a1 + a2 + a3;
	int huanchuong = b1 + b2 + b3;
	if(cup % 5 == 0){
		kq = cup/5;
	}
	else kq = cup/5 + 1;
	if(huanchuong % 10 == 0) kq1 = huanchuong/10;
	else kq1 = huanchuong/10 + 1;
	int kq2 = kq + kq1;
	if(kq2 <= n) cout << "YES";
	else cout << "NO";
}