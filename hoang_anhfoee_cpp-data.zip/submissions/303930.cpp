#include<iostream>
#include<cmath>
using namespace std;

bool checkTN(long long n){
	long long rev=0, m = n;
	while(n!=0){
		rev = rev * 10 + n%10;
		n/=10;
	}
	if(m==rev) return true;
	return false;
}

bool check6(long long n){
	while(n!=0){
		int r=n%10;
		if(r==6){
			return true;
		}
		n /= 10;
	}
	return false;
}


bool checkSum(long long n){
	long long sum=0;
	while(n!=0){
		sum += n%10;
		n /= 10;
	}
	if(sum%10==8) return true;
	return false;
}


int main(){
	int a, b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(checkTN(i) && check6(i) && checkSum(i)){
			cout << i << " ";
		}
	}
}