#include<iostream>
#include<cmath>
using namespace std;

int sum_digit(long long n){
	long long sum=0;
	while(n!=0){
		sum += n%10;
		n /=10;
	}
	return sum;
}

int main(){
	int n;
	cin >> n;
	long long x;
	for(int i=1; i<=n; i++){
		cin >> x;
		cout << sum_digit(x) << " ";
	}
}