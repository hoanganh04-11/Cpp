#include<iostream>
#include<math.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	int mod = 1e9+7;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	long long tong=0;
	long long tich=1;
	for(int i=0; i<n; i++){
		tong += (a[i]%mod);
		tong %= mod;
		tich *= (a[i]%mod);
		tich %= mod;
	}
	cout << tong << endl << tich << endl;
}