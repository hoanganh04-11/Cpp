#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long res1 = n%10;
	long long res2 = n%100;
	cout << res1 << endl;
	cout << res2 << endl;
}