#include<iostream>
#include<iomanip>
#include<math.h>
using namespace std;
int main(){
	double a;
	cin >> a;
	int kq = (int)round(a);
	cout << kq << endl;
}