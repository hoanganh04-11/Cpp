#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int x;
	int demL=0;
	int demB=0;
	cin >> x;
	for(int i=0; i<n; i++){
		if(x<a[i]){
			++demL;
		}
		if(x>a[i]){
			++demB;
		}
	}
	cout << demB << endl << demL;
}