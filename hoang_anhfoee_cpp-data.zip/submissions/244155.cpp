#include<iostream>
using namespace std;
int main(){
	char kitu;
	cin >> kitu;
	if((kitu=='Z') || (kitu=='z')){
		cout << 'a' << endl;
	}
	else if((kitu>='a') && (kitu<='z')){
		kitu += 1;
		cout << kitu << endl;
	}
	else if((kitu>='A') && (kitu<='Z')){
		kitu += 33;
		cout << kitu << endl;
	}
}