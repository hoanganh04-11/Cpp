#include<iostream>
#include<cmath>
using namespace std;

int demUoc(long long n){
	int dem=0;
	for(int i=1; i<=sqrt(n); i++){
		if(n%i==0){
			dem += 1;
			if(i != n/i){
				dem += 1;
			}
		}
	}
	return dem;
}

int main(){
	long long n;
	cin >> n;
	cout << demUoc(n);
}