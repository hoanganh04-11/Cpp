#include<bits/stdc++.h>
using namespace std;

bool prime(int n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0){
			return false;
		}
	}
	return n>1;
}

int main(){
	int n;
	cin >> n;
	int a[n];
	int demNT=0;
	long long tongNT=0;
	double tb;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		if(prime(a[i])){
			demNT += 1;
			tongNT += a[i];
		}
	}
	tb = 1.0*tongNT/demNT;
	cout << fixed << setprecision(3) << tb << endl;
}