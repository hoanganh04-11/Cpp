#include<iostream>
using namespace std;
int main(){
	int a, b, n;
	cin >> a >> b >> n;
	for(int x=0; x<=n/a; x++){
		int tu=n-a*x;
		if(tu%b==0){
			cout << "YES";
			return 0;
		}
	}
	cout <<"NO";
}