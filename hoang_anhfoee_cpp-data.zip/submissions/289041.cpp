#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int n;
	cin >> n;
	int dem=0;
	for(int i=1; i<=sqrt(n); i++){
		if(n%i==0){
			++dem;
			if(i != n/i){
				++dem;
			}
		}
	}
	cout << dem << endl;
	for(int i=n; i>=1; i--){
		if(n%i==0){
			cout << n/i <<" ";
		}
		}
}