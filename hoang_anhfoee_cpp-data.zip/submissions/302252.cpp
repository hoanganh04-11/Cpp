#include<iostream>
#include<cmath>
using namespace std;

bool cp(long long n){
	int can = sqrt(n);
	if(1ll*can*can==n){
		return true;
	}
	return false;
}

int main(){
	long long n;
	cin >> n;
	if(cp(n)){
		cout << "YES";
	}
	else cout << "NO";
}