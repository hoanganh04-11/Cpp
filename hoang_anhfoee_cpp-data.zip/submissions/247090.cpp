#include<iostream>
using namespace std;
int main(){
	long long n, s;
	cin >> n >> s;
	if(s % n == 0){
		int xu = s/n;
		cout << xu << endl;
	}
	else{
		int xu = s/n + 1;
		cout << xu << endl;
	}
}