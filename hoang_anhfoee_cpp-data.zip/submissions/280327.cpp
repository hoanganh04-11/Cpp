#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int dem=0;
	while(n>0){
		int r = n%10;
		if(r>dem){
			dem=r;
		}
		n /= 10;
	}
	cout << dem;
}