#include<bits/stdc++.h>
using namespace std;

bool dx(int a[], int n){
	for(int i=0; i<n/2; i++){
		if(a[i] != a[n-i-1]){
			return false;
		}
	}
	return true;
}

void lat(int a[], int n){
	for(int i=0; i<n/2; i++){
		swap(a[i], a[n-i-1]);
	}
}

bool dx2(int a[], int n){
	int l=0, r=n-1;
	while(l<=r){
		if(a[l] != a[r]){
			return false;
		}
		++l;
		--r;
	}
	return true;
}

int main(){
	int n; cin >> n;
	int a[n];
	for(int i=0; i<n; i++) cin >> a[i];
//	if(dx(a, n)) cout << "YES";
//	else cout << "NO";
//	lat(a, n);
//	for(int i=0; i<n; i++){
//		cout << a[i] << " ";
	if(dx2(a, n)) cout <<"YES";
	else cout <<"NO";	
}