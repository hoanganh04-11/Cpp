#include<iostream>
using namespace std;
int main(){
	int n;
	cin >>n;
	int m;
	for(int i=1; i<=n; i++){
		cin >> m;
		if(m==2022){
			cout << "YES";
			return 0;
		} 
	}
	cout << "NO";
}