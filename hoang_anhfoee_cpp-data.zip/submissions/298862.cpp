#include<iostream>
using namespace std;

bool so_dep(int n){
	int demC=0;
	int demL=0;
	while(n!=0){
		int r=n%10;
		if(r%2==0) ++demC;
		else ++demL;
		n/=10;
	}
	if(demC==demL) return 1;
	else return 0;
}

int main(){
	int n;
	cin >> n;
	for(int i=1; i<=n; i++){
		if(so_dep(i)==true){
			cout << i << " ";
		}
	}
}