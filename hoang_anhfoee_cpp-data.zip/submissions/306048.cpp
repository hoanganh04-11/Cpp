#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	int demC=0;
	int demL=0;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		if(a[i]%2==0){
			demC +=1;
		}
		else{
			demL +=1;
		}
	}
	cout << demC << " " << demL;
}