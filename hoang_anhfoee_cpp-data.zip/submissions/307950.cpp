#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int mod = 1e9+7;
	long long tich=1;
	for(int i=0; i<n; i++){
		long long x;
		cin >> x;
		tich *= (x%mod);
		tich %= mod;
	}
	cout << tich << endl;
}