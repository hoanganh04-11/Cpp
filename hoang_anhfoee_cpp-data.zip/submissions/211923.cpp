#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int r;
	cin >> r;
	double pi = 3.14;
	double p = r * 2 * pi;
	double s = r * r * pi;
	cout << fixed << setprecision(4) << p << " " << s << endl;
}