#include<iostream>
using namespace std;
int main(){
	int n; cin >> n;
	int k; cin >> k;
	int a[n];
	for(int i=0; i<n; i++) cin >> a[i];
	for(int i=0; i <= n-k; i++){
		long long sum = 0;
		for(int j=i; j <= i+k-1; j++){
			sum += a[j];
		}
		cout << sum << " ";
	}
}