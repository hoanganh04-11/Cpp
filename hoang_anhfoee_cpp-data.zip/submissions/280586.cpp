#include<iostream>
using namespace std;
int main(){
	char c;
	cin >> c;
	if(c=='u' || c=='e' || c=='o' || c=='a' || c=='i'){
		c -=32;
		cout << c << endl;
	}
	else if(c=='U' || c=='E' || c=='O' || c=='A' || c=='I'){
		cout << c << endl;
	}
	else{
		cout << (int)c << endl;
	}
}