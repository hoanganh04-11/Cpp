#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int dem=0;
	for(int i=1; i<=n; i++){
		for(int j=1; j<=n; j++){
			++dem;
			cout << dem << " ";
		}
		cout << endl;
	}
	cout << endl;
	
	for(int i=1; i<=n; i++){
		int ans=i;
		for(int j=1; j<=n; j++){
			cout << ans << " ";
			++ ans;
		}
		cout << endl;
	}
	cout << endl;
	
	for(int i=1; i<=n; i++){
		for(int j=1; j<=n-i; j++){
			cout << "~";
		}
		for(int j=1; j<=i; j++){
			cout << i;
		}
		cout << endl;
	}
	cout << endl;
	
	for(int i=1; i<=n; i++){
		int ans=i, kc=n-1;
		for(int j=1; j<=i; j++){
			cout << ans << " ";
			ans += kc;
			kc -=1;
		}
		cout << endl;
	}
}