#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int max_val = -2e9;
	int min_val = 2e9;
	int vt_min = -1, vt_max = -1;
	int i;
	for(i=0; i<n; i++){
		if(a[i] > max_val){
			max_val = a[i];
			vt_max = i;
		}
		if(a[i] <= min_val){
			min_val = a[i];
			vt_min = i;
		}
	}
	cout << vt_min << " " << vt_max;
}