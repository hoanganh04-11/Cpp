#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int a,b;
	cin >> b >> a;
	int res1 = a/b;
	double res2 = (double)a/b;
	cout << res1 << endl;
	cout << fixed << setprecision(2) << res2 << endl;
}