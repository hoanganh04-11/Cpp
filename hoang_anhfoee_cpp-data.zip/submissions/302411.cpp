#include<iostream>
#include<cmath>
using namespace std;


int main(){
	long long a, b;
	cin >> a >> b;
	int can= ceil(sqrt(a));
	int dem=0;
	for(int i=can; i<=sqrt(b); i++){
		++dem;
	}
	cout << dem;
}