#include<bits/stdc++.h>
using namespace std;
int main(){
	int a, b;
	cin >> a >> b;
	bool check = false;
	for(int i= min(a, b); i<=max(a, b); i++){
		if((i%2==0) || (i%3==0) || (i%5==0)){
			cout << i << " ";
			check = true;
		}
	}
	if(!check==true){
		cout << "28tech";
	}
}