#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long res1 = 1ll* n * 2;
	long long res2 = 1ll* n * 10;
	long long res3 = 1ll * n / 2;
	double res4 = (double)n / 2;
	cout << res1 << endl;
	cout << res2 << endl;
	cout << res3 << endl;
	cout << fixed << setprecision(3) << res4 << endl;
}