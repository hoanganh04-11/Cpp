#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int x; 
	cin >> x;
	int demL=0;
	int demB=0;
	for(int i=0; i<n; i++){
		if(a[i]>x){
			++demL;
		}
		else if(a[i]<x){
			++demB;
		}
	}
	cout << demB << endl << demL;
}