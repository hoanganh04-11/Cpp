#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long res = n/1000;
	cout << res << endl;
}