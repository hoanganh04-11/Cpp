#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	long long k2, k3, k5, k6;
	cin >> k2 >> k3 >> k5 >> k6;
	long long sum1 = min({k2,k5,k6});
	long long sum2 = min(k3, k2-sum1);
	cout << sum1 * 256 + sum2 * 32 << endl;
}