#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int chan=0;
	int le=0;
	if(n==0){
		chan += 1;
	}
	while(n!=0){
		long long r= n%10;
		if(r%2==0){
			++chan;
		}
		else{
			++le;
		}
		n /= 10;
	}
	if(le<chan){
		cout << "28tech" << endl;
	}
	else{
		cout << "29tech" << endl;
	}
}