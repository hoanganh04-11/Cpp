#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	for(int i = 0; i < n; i++){
		cout<< "Hello 28tech" <<" "<< endl;
	}
	for(int a=1; a <= n; a++){
		cout<< a << " " ;
	}
	cout << endl;
	for(int b=0; b <= n-1; b++){
		cout<< b << " " ;
	}
	cout << endl;
	for(int c=n; c>=1; c--){
		cout<< c << " " ;
	}
	cout << endl;
	for(int d=n-1; d>=0; d--){
		cout<< d << " " ;
	}
}