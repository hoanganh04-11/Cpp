#include<iostream>
using namespace std;

//ktra chan co nhieu hon le hay ko
bool chanle(int n){
	int demC=0;
	int demL=0;
	while(n){
		int r=n%10;
		if(r%2==0) ++demC;
		else ++demL;
		n /=10;
	}
	if(demC>demL) return 1;
	else return 0;
}

bool check(int n){
	int sum=0;
	while(n){
		sum += n%10;
		n /=10;
	}
	if(chanle(sum)==1){
		return 1;
	}
	else return 0;
}

int main(){
	int n;
	cin >> n;
	for(int i=1; i<=n; i++){
		if(check(i)==true){
			cout << i << " ";
		}
	}
}