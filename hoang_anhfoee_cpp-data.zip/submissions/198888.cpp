#include<iostream>
using namespace std;
int main(){
	int a,b;
	cin >> a >> b;
	long long s= 1ll * a * b;
	int p=(long long) 2 * (a+b);
	cout << "Chu vi HCN la : " << p << endl;
	cout << "Dien tich HCN la : " << s << endl;
}