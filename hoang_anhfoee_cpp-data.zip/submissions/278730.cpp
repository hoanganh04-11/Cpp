#include<iostream>
using namespace std;
int main(){
	int n, i=3;
	cin >> n;
	while(i<=n){
		cout << i << " ";
		i +=3;
	}
	cout << endl;
	i=0;
	while(i<n){
		if(i%3==0 && i%5==0){
			cout << i << " ";
		}
		++i;
	}
	cout << endl;
	i=n; 
	while(n!=0){
		if(i%7==0){
			cout << i << endl;
			break;
		}
		++i;
	}
	i=n;
	while(n!=0){
		if(i%9==0){
			cout << i << endl;
			break;
		}
		--i;
	}
	i=1;
	while(i <= 2*n-1){
		cout << i << " ";
		i += 2;
	}
}