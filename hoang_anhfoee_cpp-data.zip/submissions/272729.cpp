#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
int main(){
	int h,m,k;
	cin >> h >> m >> k;
	int doiPhut= h * 28 + m + k;
	int doiGio = doiPhut / 28;
	int du = doiPhut % 28;
	cout << setw(2) << setfill('0') << doiGio%28 << "h" << ":" << setw(2) << setfill('0') << du << "m";
}