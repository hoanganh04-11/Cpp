#include<iostream>
using namespace std;
int main(){
	int n; cin >> n;
	int demT=0, demH=0, demS=0, demDB=0;
	for(int i=0; i<n; i++){
		char c;
		cin >> c;
		if((c>='a')&&(c<='z')){
			++demT;
		}
		else if((c>='A')&&(c<='Z')){
			++demH;
		}
		else if((c>='0')&&(c<='9')){
			++demS;
		}
		else{
			++demDB;
		}
	}
	cout << demT << " " << demH << " " << demS << " " << demDB;
}