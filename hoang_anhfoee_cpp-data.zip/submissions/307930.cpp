#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int mod = 1e9+7;
	long long tong=0;
	for(int i=0; i<n; i++){
		long long x;
		cin >> x;
		tong += (x%mod);
	}
	cout << tong%mod << endl;
}