#include<iostream>
using namespace std;
int main(){
	long long x,y,z;
	cin >> x >> y >> z;
	int a=x % 10;
	int b=y % 100;
	int c=z % 1000;
	int h=a + b + c;
	cout << h << endl;
}