#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int dem=0;
	while(n>0){
		long long r = n % 10;
		if(r==3 || r==5 || r==7 || r== 2){
			++dem;
		}
		n /= 10;
	}
	cout << dem << endl;
}