#include<iostream>
using namespace std;
int main(){
	int n;
	int mod = 1e9+7;
	cin >> n;
	int a[n];
	long long tich=1;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		tich *= (a[i]%mod);
		tich %= mod;
	}
	cout << tich;
}