#include<iostream>
using namespace std;
int main(){
	long long n, a, b;
	cin >> n >> a >> b;
	if(2*a < b){
		long long cost1 = n*a;
		cout << cost1 << endl;
	}
	if(2*a > b){
		if(n%2==0){
			long long cost2 = (n/2)*b;
			cout << cost2 << endl;
		}
		else{
			long long cost3 = (n/2)*b+1*a;
			cout << cost3 << endl;
		}
	}
}