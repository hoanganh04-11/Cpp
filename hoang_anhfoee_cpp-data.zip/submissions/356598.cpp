#include<iostream>
using namespace std;
int main(){
	int n, m, p; cin >> n >> m >> p;
	int a[n];
	int b[m];
	for(int i=0; i<n; i++) cin >> a[i];
	for(int i=0; i<m; i++) cin >> b[i];
	for(int i=0; i<n; i++){
		if(i==p){
			for(int i=0; i<m; i++){
				cout << b[i] << " ";
			}
		}
		cout << a[i] << " ";
	}
	if(p==n){
		for(int i=0; i<m; i++){
			cout << b[i] << " ";
		}
	}
}