#include<bits/stdc++.h>
using namespace std;
int main(){
	int n; cin >> n;
	vector<pair<int, int>> v(n);
	for(int i=0; i<n; i++){
		cin >> v[i].first >> v[i].second;
	}
	for(int i=0; i<n; i++){
		double kq = 1.0 * sqrt(pow(v[i].first, 2) + pow(v[i].second, 2));
		cout << fixed << setprecision(2) << kq << " ";
	}
}