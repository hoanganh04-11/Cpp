#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	if(n==0) cout << 0;
	else{
		int dai=0;
		long long m=n;
		while(m>0){
			dai++;
			m /=10; 
	}
	if (dai%2==0) cout << "NOT FOUND";
	else{
		dai = dai/2+1; 
		int d=0;
	while(n>0){
		++d;
		if(d==dai){
			cout << n%10;
			break;
		}
		n /=10;
	}
	}
}
}