#include<iostream>
#include<vector>
using namespace std;
int main(){
    int m; cin >> m;
    vector<int> v(m);
    for(int i=0; i<m; i++) cin >> v[i];
    int n; cin >> n;
    while(n--){
        int tt; cin >> tt;
        if(tt==1){
            int x; cin >> x;
            int y; cin >> y;
            if(x>=0 && x<=v.size()) v.insert(v.begin() + x, y);
        }
        else{
            int x; cin >> x;
            if(x>=0 && x<v.size()) v.erase(v.begin() + x);
        }
    }
    if(v.empty()) cout << "EMPTY";
    else{
        for(int i=0; i < v.size(); i++){
            cout << v[i] << " ";
        }
    }
}