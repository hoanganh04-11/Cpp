#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	int mod=1e9+7;
	long long tich=1;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		tich *= (a[i]%mod);
		tich %= mod;
	}
	cout << tich;
}