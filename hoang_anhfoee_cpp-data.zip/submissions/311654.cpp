#include<iostream>
using namespace std;
int main(){
	long long a, b;
	cin >> a >> b;
	long long gt=1;
	if(a>=b){
		for(int i=1; i<=b; i++){
			gt *= i;
		}
	}
	else{
		for(int i=1; i<=a; i++){
			gt *= i;
		}
	}
	cout << gt;
}