#include<bits/stdc++.h>
using namespace std;

bool nt(long long n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0){
			return false;
		}
	}
	return n>1;
}

int main(){
	int n; cin >> n;
	int a[n];
	int left, right;
	long long sumLeft=0;
	long long sumRight=0;
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	for(int i=0; i<n; i++){
		for(left=0; left<i; left++){
			sumLeft += a[left];
		}
		for(right=i+1; right<n; right++){
			sumRight += a[right];
		}
		if(nt(sumLeft)==true && nt(sumRight)==true){
			cout << i << " ";
		}
		sumLeft=0;
		sumRight=0;
	}
}