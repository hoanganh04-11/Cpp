#include<iostream>
using namespace std;

bool chia6(int n){
	while(n!=0){
		int r=n%10;
		if(r==6) return 1;
		n /=10;
	}
	return 0;
}

bool tongC(int n){
	int tong=0;
	while(n!=0){
		tong += n%10;
		n /=10;
	}
	if(tong%2==0) return 1;
	else return 0;
}

bool ktra(int n){
	int demL=0;
	int demC=0;
	while(n!=0){
		int r=n%10;
		if(r%2==0) ++demC;
		else ++demL;
		n /=10;
	}
	if(demL>demC) return 1;
	else return 0;
}


int main(){
	int a,b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(chia6(i) && tongC(i) && ktra(i)){
			cout << i << " ";
		}
	}
}