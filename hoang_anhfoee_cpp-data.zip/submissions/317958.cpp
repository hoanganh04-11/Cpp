#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	for(int i=1; i<=n; i++){
		if(i%2==0){
			char c = 'a' + i - 1;
			for(int j=1; j<=n; j++){
				cout << c;
				++c;
			}
		}
		else{
			char c = 'A' + i - 1;
			for(int j=1; j<=n; j++){
				cout << c;
				++c;
			}
		}
		cout << endl;
	}
}