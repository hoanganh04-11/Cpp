#include<iostream>
using namespace std;
int main(){
	int n; 
	cin >> n;
	for(int i=1; i<=n; i++){
		int ans=i;
		//left
		for(int j=1; j<=n-i; j++){
			cout << " " << " ";
		}
		for(int j=1; j<=i-1; j++){
			cout << ans << " ";
			++ans;
		} 
		//mid
		cout << 2*i-1 << " ";
		//right
		int num=2*i-2;
		for(int j=1; j<=i-1; j++){
			cout << num << " ";
			--num;
		}
		cout << endl;
	}
}