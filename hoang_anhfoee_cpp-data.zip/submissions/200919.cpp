#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;
int main(){
	int x,y;
	cin >> x >> y;
	long long res = (long long)pow(x,y);
	cout << res << endl;
}