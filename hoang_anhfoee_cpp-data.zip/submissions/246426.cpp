#include<iostream>
using namespace std;
int main(){
	long long m,n;
	cin >> m >> n;
	if(m % 2 != 0){
		long long doc = ((m-1)*n)/2;
		long long ngang = n/2;
		long long soDomino = doc + ngang;
		cout << soDomino << endl;
	}
	else{
		long long soDomino = (m/2)*n;
		cout << soDomino << endl;
	}
}