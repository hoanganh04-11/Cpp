#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int dem=0;
	if(n==1) cout << "-1";
	else{
	if(n%2==0){
		dem = n/2;
		cout << dem << endl;
		for(int i=1; i<=n/2; i++){
			int cnt=2;
			cout << cnt << " ";
		}
	}
	else{
		dem = (n-3)/2+1;
		cout << dem << endl;
		for(int i=1; i<=(n-3)/2; i++){
			int cnt=2;
			cout << cnt << " ";
		}
		cout << "3";
	}
}
}