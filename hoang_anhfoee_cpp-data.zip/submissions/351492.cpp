#include<iostream>
#include<cmath>
using namespace std;

#define ll long long

int gcd(int a,int b){
	while(b!=0){
		int tmp = a%b;
		a = b;
		b = tmp;
	}
	return a;
}

int main(){
	int n; cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int r = a[0];
	for(int i=1; i<n; i++){
		r = gcd(r, a[i]);
	}
	cout << r;
}