#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	long long d1, d2, d3;
	cin >> d1 >> d2 >> d3;
	long long x1= d1 + d2 + d3;
	long long x2= 2*d1 + 2*d3;
	long long x3= 2*d2 + 2*d3;
	long long x4= 2*d1 + 2*d2;
	cout << min({x1, x2, x3, x4});
}