#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int bia = n/28;
	int vo = bia;
	while(vo>=3){
		int t=vo/3; //so chai bia doi duoc tu vo
		vo %=3; //du 
		vo += t;
		bia += t;
	}
	cout << bia;
}