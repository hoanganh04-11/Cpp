#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	bool check = true;
	if(n==0){
		cout << "28tech";
	}
	else{
	while(n!=0){
		int r=n%10;
		if(r%2 !=0){
			check = false;
			break;
		}
		n /= 10;
	}
	if(check){
		cout << "28tech";
	}
	else cout << "29tech";
	}
}