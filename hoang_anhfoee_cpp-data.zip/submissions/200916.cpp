#include<iostream>
using namespace std;
int main(){
	int x, y, z, t;
	cin >> x >> y >> z >> t;
	long long s= 1ll* x + y + z + t;
	long long s1 = x-y+1ll*z*t;
	cout <<y<<","<<z<<","<<x<<","<<t<< endl;
	cout << s << endl;
	cout << s1 << endl;
}