#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	int a[n];
	for(int i=0; i<n; i++){
		cin >> a[i];
	}
	int max_val1 = INT_MIN;
	int max_val2 = INT_MIN; 
	for(int i=0; i<n; i++){
		if(a[i] > max_val1){
			max_val2 = max_val1;
			max_val1 = a[i];
		}
		else if(a[i] > max_val2){
			max_val2 = a[i];
		}
	}
	cout << max_val1 << " " << max_val2;
}