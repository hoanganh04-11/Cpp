#include<iostream>
#include<iomanip>
#include<math.h>
using namespace std;
int main(){
	int n;
	cin >> n;
	double res1 = (double)sqrt(n);
	double res2 = (double)cbrt(n);
	cout << fixed << setprecision(2) << res1 << endl;
	cout << fixed << setprecision(3) << res2 << endl;
}