#include<iostream>
#include<cmath>
using namespace std;
int main(){
	long long a,b;
	cin >> a >> b;
	int c1=ceil(sqrt(a));
	int c2=sqrt(b);
	cout << c2-c1+1 << endl;
}