#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long s=1;
	int i=1;
	while(i <= n){
		s *= i;
		++i;
	}
	cout << s << endl;
}