#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int hangDV = n%10;
	int hangC = (n/10)%10;
	if((hangDV % 2 == 0 && hangC % 2 == 0) || (hangDV % 2 != 0 && hangC % 2 != 0)){
		cout << "28tech";
	}
	else{
		cout << "29tech";
	}
}