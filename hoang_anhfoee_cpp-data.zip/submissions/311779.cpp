#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int n;
	cin >> n;
	long long gt=1;
	double e=1;
	for(int i=1; i<=n; i++){
		gt *= i;
		e += 1.0/gt;
	}
	cout << fixed << setprecision(2) << e << endl;
}