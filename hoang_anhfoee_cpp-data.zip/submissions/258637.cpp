#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int a, b;
	char X;
	cin >> a >> b >> X;
	if(X=='+'){
		cout << a << " " << X << " " << b << " " << '=' << " " << a+b << endl;
	}
	else if(X=='-'){
		cout << a << " " << X << " " << b << " " << '=' << " " << a-b << endl;
	}
	else if(X=='*'){
		cout << a << " " << X << " " << b << " " << '=' << " " << a*b << endl;
	}
	else if(X=='/'){
		double kq = (double)a/b;
		cout << a << " " << X << " " << b << " " << '=' << " ";
		cout << fixed << setprecision(2) << kq << endl;
	}
	else if(X=='%'){
		cout << a << " " << X << " " << b << " " << '=' << " " << a % b << endl;
	}
}