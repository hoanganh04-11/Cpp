#include<iostream>
using namespace std;

bool so_tang(int n){
	while(n>=10){
		int trc=(n/10)%10;
		int sau=n%10;
		if(trc >= sau) return false;
		n /=10;
	}
	return true;
}



int main(){
	int a,b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(so_tang(i)==true){
			cout << i << " ";
		}
	}
}