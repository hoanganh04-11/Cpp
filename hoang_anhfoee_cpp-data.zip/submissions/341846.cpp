#include<bits/stdc++.h>
using namespace std;

bool prime(int n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0){
			return false;
		}
	}
	return n>1;
}

bool tongunt(int n){
	long long sum=0;
	for(int i=1; i<=sqrt(n); i++){
		if(n%i==0){
			if(prime(i)){
				sum += i;
			}
			if(i != n/i){
				if(prime(n/i)){
					sum += n/i;
				}
			}
		}
	}
	return !prime(sum);
}

int main(){
	int a, b;
	cin >> a >> b;
	bool check = false;
	for(int i=a; i<=b; i++){
		if(tongunt(i)){
			cout << i << " ";
			check = true;
		}
	}
	if(!check) cout << "28tech";
}