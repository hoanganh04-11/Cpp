#include<iostream>
using namespace std;
int main(){
	long long n;
	cin >> n;
	long long thunhap;
	long long thue;
	if(n>80000000){
		thue = n/100*35;
		thunhap = n-thue;
	}
	else if(n>52000000){
		thue = n/100*30;
		thunhap = n-thue;	
	}
	else if(n>32000000){
		thue = n/100*25;
		thunhap = n-thue;
	}
	else if(n>18000000){
		thue = n/100*20;
		thunhap = n-thue;
	}
	else if(n>10000000){
		thue = n/100*15;
		thunhap = n-thue;
	}
	else if(n>5000000){
		thue = n/100*10;
		thunhap = n-thue;
	}
	else{
		thue = n/100*5;
		thunhap = n-thue;
	}
	cout << "Thu nhap" << " " << ":" << " " << thunhap << " " << "VND" << endl;
	cout << "Thue" << " " << ":" << " " << thue << " " << "VND" << endl;
}