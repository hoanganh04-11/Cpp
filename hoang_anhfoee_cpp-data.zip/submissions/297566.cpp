#include<iostream>
using namespace std;

bool check(long long n){
	int sum=0;
	while(n!=0){
		sum += n%10;
		n /=10;
	}
	int r=sum%10;
	if(r==8){
		return 1;
	}
	else{
		return 0;
	}
}

int main(){
	long long x;
	cin >> x;
	if(check(x)==true){
		cout << "28tech";
	}
	else{
		cout << "29tech";
	}
}