#include<iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	int dem=0;
	int demSo=0;
	for(int i=0; i<n; i++){
		char c;
		cin >> c;
		if((c>='A'&&c<='Z')||(c>='a'&&c<='z')) ++dem;
		if(c>='0'&&c<='9'){
			demSo += (c-'0');
		}
	}
	cout << dem << endl;
	cout << demSo << endl;
}