#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	double f;
	cin >> f;
	int a = (int)f;
	double b= f-a; 
	cout << a << endl;
	cout << fixed << setprecision(2) << b << endl;
}