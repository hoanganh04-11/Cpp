#include<bits/stdc++.h>
using namespace std;

long long gt(long long n){
	long long kq=1;
	for(int i=1; i<=n; i++){
		kq *= i;
	}
	return kq;
}

bool str(int n){
	long long sum=0;
	int m = n;
	while(m != 0){
		sum += gt(m%10);
		m /= 10; 
	}
	return sum == n;
}


int main(){
	int a, b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(str(i) && i != 0){
			cout << i << " ";
		}
	}
}