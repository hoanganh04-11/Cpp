#include<bits/stdc++.h>
using namespace std;

bool nt(int n){
	for(int i=2; i<=sqrt(n); i++){
		if(n%i==0){
			return false;
		}
	}
	return n>1;
}

bool check(int n){
	int m = n;
	while(m >= 10){
		int r = m%10;
		int x = (m/10 % 10);
		if(x>r){
			return false;
		}
		m /= 10;
	}
	return true;
}

int main(){
	int a, b;
	cin >> a >> b;
	for(int i=a; i<=b; i++){
		if(check(i)&&nt(i)){
			cout << i << " ";
		}
	}
}