#include <bits/stdc++.h>

using namespace std;

int main() {
    int a,b,c;
    cin >> a >> b >> c;
    long long dienTich = (long long) a*b*c;
    cout << dienTich << endl;
    return 0;
}