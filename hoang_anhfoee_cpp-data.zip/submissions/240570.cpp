#include<iostream>
using namespace std;
int main(){
	double a, b, c, d;
	cin >> a >> b >> c >> d;
	double kq = (a + b + c*2 + d*3)/7;
	if(kq >= 8){
		cout << "GIOI" << endl;
	}
	else if(kq >= 6.5){
		cout << "KHA" << endl;
	}
	else if(kq >= 5){
		cout << "TRUNG BINH" << endl;
	}
	else if(kq < 5){
		cout << "YEU" << endl;
	}
}