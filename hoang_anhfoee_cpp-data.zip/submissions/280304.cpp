#include<iostream>
#include<cmath>
using namespace std;
int main(){
	long long n;
	cin >> n;
	int previousDigit = n%10;
	n /= 10;
	int currentDigit;
	int sum = 0;
	while(n>0){
		currentDigit = n % 10;
		sum += abs(currentDigit - previousDigit);
		previousDigit = currentDigit;
		n /= 10;
	}
	cout << sum << endl;
}